for(var i = 0; i < 225; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u151'] = 'top';u42.tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业拓展.html');

}
});
gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u159'] = 'center';u55.tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('网站投诉.html'), "");

}
});
gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u138'] = 'top';u52.tabIndex = 0;

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('联系我们.html'), "");

}
});
gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u89'] = 'top';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u213'] = 'center';gv_vAlignTable['u184'] = 'center';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u112'] = 'top';u44.tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('高级搜索.html');

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u179'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u125'] = 'center';u41.tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业内训.html');

}
});
gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u149'] = 'top';u54.tabIndex = 0;

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('意见反馈.html'), "");

}
});
gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u197'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u216'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u85'] = 'top';u51.tabIndex = 0;

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('成功案例.html');

}
});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u182'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u219'] = 'top';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u114'] = 'center';u223.tabIndex = 0;

u223.style.cursor = 'pointer';
$axure.eventManager.click('u223', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('网站地图.html'), "");

}
});
gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u92'] = 'top';u46.tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('关于我们.html');

}
});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u127'] = 'center';u43.tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('咨询团队.html');

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u154'] = 'top';u40.tabIndex = 0;

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('公开课.html');

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u87'] = 'top';u53.tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('培训地图.html'), "");

}
});
gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u192'] = 'center';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u84'] = 'center';u50.tabIndex = 0;

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('精品文章列表.html');

}
});
gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u209'] = 'center';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'center';u49.tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('公司新闻列表.html');

}
});
gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u167'] = 'top';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u201'] = 'center';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u161'] = 'center';u45.tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('培训资讯.html');

}
});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u218'] = 'center';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u194'] = 'center';