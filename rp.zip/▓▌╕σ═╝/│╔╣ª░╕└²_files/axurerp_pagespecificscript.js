for(var i = 0; i < 52; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('咨询团队.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u6'] = 'center';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u13'] = 'top';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('培训资讯.html');

}
});
gv_vAlignTable['u38'] = 'top';u43.tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('精品文章列表.html');

}
});
gv_vAlignTable['u43'] = 'top';u44.tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u1'] = 'center';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('高级搜索.html');

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u10'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('网站地图.html'), "");

}
});
gv_vAlignTable['u11'] = 'top';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('关于我们.html');

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u9'] = 'top';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业拓展.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'top';u42.tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('公司新闻列表.html');

}
});
gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u4'] = 'center';u46.tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('培训地图.html'), "");

}
});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u20'] = 'center';u48.tabIndex = 0;

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('网站投诉.html'), "");

}
});
gv_vAlignTable['u48'] = 'top';u47.tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('意见反馈.html'), "");

}
});
gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u25'] = 'center';u45.tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('联系我们.html'), "");

}
});
gv_vAlignTable['u45'] = 'top';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('公开课.html');

}
});
gv_vAlignTable['u33'] = 'top';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业内训.html');

}
});
gv_vAlignTable['u34'] = 'top';