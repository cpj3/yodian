for(var i = 0; i < 219; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'top';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('联系我们.html'), "");

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u186'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('培训资讯.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('成功案例.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u141'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业拓展.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u164'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u179'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u149'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u182'] = 'top';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业内训.html');

}
});
gv_vAlignTable['u10'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('意见反馈.html'), "");

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u157'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u193'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u121'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('精品文章列表.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u177'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u102'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('公开课.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u147'] = 'top';gv_vAlignTable['u163'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u70'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('网站投诉.html'), "");

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u210'] = 'center';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('高级搜索.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u175'] = 'top';u217.tabIndex = 0;

u217.style.cursor = 'pointer';
$axure.eventManager.click('u217', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('网站地图.html'), "");

}
});
gv_vAlignTable['u217'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u183'] = 'top';gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u178'] = 'top';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u196'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('关于我们.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u167'] = 'top';gv_vAlignTable['u145'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('咨询团队.html');

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u90'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('公司新闻列表.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u161'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u77'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('培训地图.html'), "");

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u194'] = 'top';